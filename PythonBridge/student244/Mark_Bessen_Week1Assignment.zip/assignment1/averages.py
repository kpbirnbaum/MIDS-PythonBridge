from math import sqrt

a = float(input("Enter your first number: "))
b = float(input("Enter your second number: "))
n = 2 # will be used for root-mean-square

arithmetic_mean = (a + b) / 2
geometric_mean = sqrt(a * b)
root_mean_square = sqrt((a**2 + b**2) / n)

print("""The arithmetic mean is %.2f.
The geometric mean is %.2f.
The root-mean-square is %.2f."""
      % (arithmetic_mean, geometric_mean, root_mean_square))
