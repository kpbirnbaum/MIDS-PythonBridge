gallons = float(input("Enter the number of gallons of gasoline: "))

liters = gallons * 3.7854 # 1 gallon is equal to 3.7854 liters
barrels = gallons / 19.5 # 1 barrel produces 19.5 gallons
price = gallons * 3.65 # average price of gas per gallon is $3.65

print("""You input %.2f gallons of gas.
That is equivalent to %.2f liters of gas.
It took %.2f barrels of oil to make that gas.
Your gas cost $%.2f.""" % (gallons, liters, barrels, price))
