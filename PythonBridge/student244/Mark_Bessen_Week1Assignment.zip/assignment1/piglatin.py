name = str(input('Enter your name: ')).lower().split()
vowels = ('a', 'e', 'i', 'o', 'u')
translated = ''
for word in name:
    if word[0] in vowels:
        translated += word + 'hay '
    else:
        translated += word[1:] + word[0] + 'ay '
print(translated.title())
