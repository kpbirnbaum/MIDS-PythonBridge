price = float(input("Enter the price of a meal: "))

tip = price * 0.16
total = price + tip

print("A 16 percent tip is $%.2f" % (tip))
print("The total price is $%.2f" % (total))
